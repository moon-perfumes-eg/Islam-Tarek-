ISLAM TAREK PERSONAL WEBSITE — GITHUB PAGES

Expected repository name: islam-tarek
GitHub account: moon-perfumes-eg
Expected public URL: https://moon-perfumes-eg.github.io/islam-tarek/

PUBLISH:
1. Sign in to GitHub as moon-perfumes-eg.
2. Create a new PUBLIC repository named islam-tarek.
3. Upload index.html, robots.txt, and sitemap.xml to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish the site.

AFTER PUBLISHING:
1. Open the expected URL and confirm it loads.
2. Add the URL to Google Search Console and verify ownership using one of Google's offered methods.
3. Submit https://moon-perfumes-eg.github.io/islam-tarek/sitemap.xml.
4. Use URL Inspection to request indexing of the homepage.

NOTES:
- The portrait is a clearly marked placeholder; replace it with a real photo of Islam before launch if possible.
- No contact email has been added because none has been confirmed for public display.
- ProfilePage/Person structured data helps Google interpret the page; it does not guarantee indexing, a Knowledge Panel, or a special search result.
- The website text is intentionally modest and does not claim unverified achievements or audience statistics.
